/********************************************************************
 * hfsc_scheduler.h — Hierarchical Fair Service Curve Scheduler v2.3
 *
 * References:
 *   [1] Stoica et al., "A Hierarchical Fair Service Curve Algorithm
 *       for Link-Sharing, Real-Time and Priority Service"
 *       IEEE/ACM Transactions on Networking, 1997.
 *   [2] Linux kernel net/sched/sch_hfsc.c
 *
 * DPDK Userspace Implementation — Aligned with Linux Kernel Logic
 *
 * Changes in v2.3:
 *   - VT snapping logic fixed to match Linux kernel (parent->cl_cvtmin)
 *   - Generation counter names clarified (deactivation_gen, last_active_gen)
 *   - Constant rate curve optimization (m1==m2 → no burst)
 *   - RT heap selection optimized (check heap top first)
 *   - Ancestor propagation order fixed (VT update before cvtmin refresh)
 *   - USC application on interior nodes corrected
 *
 ********************************************************************/

#ifndef HFSC_SCHEDULER_H
#define HFSC_SCHEDULER_H

#include <stdint.h>
#include <stdbool.h>
#include <rte_mbuf.h>
#include <rte_ring.h>
#include <rte_cycles.h>
#include <rte_log.h>

/* ----------------------------------------------------------------
 * Compile-time limits
 * ---------------------------------------------------------------- */
#define HFSC_MAX_CLASSES        256    /* total classes in the hierarchy    */
#define HFSC_MAX_CHILDREN       32     /* max children per interior node    */
#define HFSC_QUEUE_SIZE         8192   /* per-leaf ring size (power of 2)   */

/**
 * HFSC_FIXEDPOINT_SHIFT — fractional bits in slope values.
 * slope = (rate_bytes_per_sec << SHIFT) / tsc_cycles_per_second
 * 24 bits: sub-nanosecond precision at 3 GHz, no 64-bit overflow
 * for intervals up to ~1 second.
 */
#define HFSC_FIXEDPOINT_SHIFT   24


/* ================================================================
 * USER-FACING SERVICE CURVE
 * ================================================================ */

/**
 * hfsc_service_curve_t — two-piece linear service curve.
 *
 * Constant rate:   m1 = m2, d = 0
 * Burst then rate: m1 > m2, d = burst window in microseconds
 */
typedef struct {
    uint64_t m1;  /* initial slope    (bytes/sec)    */
    uint64_t d;   /* burst window     (microseconds) */
    uint64_t m2;  /* sustained slope  (bytes/sec)    */
} hfsc_service_curve_t;


/* ================================================================
 * INTERNAL RUNTIME CURVE SEGMENT
 * ================================================================ */

/**
 * hfsc_internal_curve_t — running two-piece linear segment.
 *
 * Anchored at (cl_x, cl_y):
 *   bytes(t) = cl_y + slope_initial   * (t − cl_x)
 *                        for t ∈ [cl_x,  cl_x + burst_duration]
 *   bytes(t) = cl_y + burst_bytes
 *              + slope_sustained * (t − cl_x − burst_duration)
 *                        for t >  cl_x + burst_duration
 *
 * slope_initial / slope_sustained: fixed-point bytes/cycle
 *   = (bytes_per_sec << HFSC_FIXEDPOINT_SHIFT) / tsc_hz
 */
typedef struct {
    uint64_t cl_x;            /* anchor time   (TSC cycles)              */
    uint64_t cl_y;            /* anchor bytes  (cumulative at cl_x)      */
    uint64_t burst_duration;  /* initial-segment length (TSC cycles)     */
    uint64_t burst_bytes;     /* bytes delivered in the initial segment  */
    uint64_t slope_initial;   /* initial slope  (fixed-point bytes/cycle)*/
    uint64_t slope_sustained; /* sustained slope (fixed-point bytes/cycle)*/
} hfsc_internal_curve_t;


/* ================================================================
 * TRAFFIC CLASS
 * ================================================================ */

typedef struct hfsc_class hfsc_class_t;

/**
 * hfsc_class_t — one node in the HFSC class hierarchy.
 *
 * Interior nodes: no queue, compete via their own FSC/cl_vt.
 * Leaf nodes:     hold a packet queue, are directly transmitted.
 *
 * Cache-line optimization: hot fields placed first for reduced misses.
 */
struct hfsc_class {
    /* ---- Hot fields (Cache Line 1) ---- */
    bool           is_active;                              /* 1 byte */
    bool           is_leaf;                                /* 1 byte */
    bool           has_rsc;                                /* 1 byte */
    bool           has_usc;                                /* 1 byte */
    uint32_t       class_id;                               /* 4 bytes */
    uint32_t       qlen;                                   /* 4 bytes */
    uint64_t       qbytes;                                 /* 8 bytes */
    uint64_t       cl_vt;                                  /* 8 bytes */
    uint64_t       vt_offset;                              /* 8 bytes */
    uint64_t       cl_e;                                   /* 8 bytes */
    uint64_t       cl_d;                                   /* 8 bytes */
    uint64_t       cl_myf;                                 /* 8 bytes */
    int            deadline_heap_index;                    /* 4 bytes */
    uint32_t       deactivation_gen;                       /* 4 bytes */
    uint32_t       last_active_gen;                        /* 4 bytes */
    /* ---- Cache Line 1 End (~80 bytes) ---- */

    /* ---- Hierarchy ---- */
    hfsc_class_t  *parent;
    hfsc_class_t  *children[HFSC_MAX_CHILDREN];
    uint32_t       num_children;

    /* ---- Packet queue (leaf only) ---- */
    struct rte_ring *queue;

    /* ---- User service curves ---- */
    hfsc_service_curve_t rsc;      /* real-time curve   */
    hfsc_service_curve_t fsc;      /* fair-share curve  */
    hfsc_service_curve_t usc;      /* upper-limit curve */

    /* ---- Runtime curves (re-anchored after every packet) ---- */
    hfsc_internal_curve_t rt_deadline_curve;      /* RSC running segment  */
    hfsc_internal_curve_t ls_virtual_time_curve;  /* FSC running segment  */
    hfsc_internal_curve_t ul_fittime_curve;       /* USC running segment  */
    hfsc_internal_curve_t rt_eligible_curve;      /* concave hull of RSC  */

    /* ---- Byte counters ---- */
    uint64_t cumul;   /* bytes served — used by RSC/eligible inverses (RT) */
    uint64_t total;   /* bytes served — used by FSC/USC inverses  (LS/USC) */

    /* ---- Children VT range (interior nodes) ---- */
    uint64_t cl_cvtmin;  /* min cl_vt of active children  */
    uint64_t cl_cvtmax;  /* max cl_vt of active children  */

    /* ---- Per-class statistics ---- */
    uint64_t stat_packets_sent;
    uint64_t stat_bytes_sent;
    uint64_t stat_packets_dropped;
};


/* ================================================================
 * SCHEDULER
 * ================================================================ */

typedef struct {
    hfsc_class_t   *root_class;
    hfsc_class_t   *all_classes[HFSC_MAX_CLASSES];
    uint32_t        num_classes;

    hfsc_class_t  **rt_deadline_heap;   /* min-heap by cl_d */
    uint32_t        rt_heap_size;
    uint32_t        rt_heap_capacity;

    uint64_t        tsc_cycles_per_second;

    uint64_t        total_packets_enqueued;
    uint64_t        total_packets_dequeued;
    uint64_t        total_packets_dropped;
} hfsc_scheduler_t;


/* ================================================================
 * PUBLIC API
 * ================================================================ */

int  hfsc_init(hfsc_scheduler_t **sched_out);
void hfsc_cleanup(hfsc_scheduler_t *sched);

hfsc_class_t *hfsc_create_root(hfsc_scheduler_t          *sched,
                                const hfsc_service_curve_t *rsc,
                                const hfsc_service_curve_t *fsc,
                                const hfsc_service_curve_t *usc);

/**
 * hfsc_create_class — create an interior or leaf class.
 *  rsc  NULL → no RT guarantee
 *  fsc  required, m2 must be > 0
 *  usc  NULL → no bandwidth cap
 */
hfsc_class_t *hfsc_create_class(hfsc_scheduler_t          *sched,
                                 hfsc_class_t              *parent,
                                 uint32_t                   class_id,
                                 bool                       is_leaf,
                                 const hfsc_service_curve_t *rsc,
                                 const hfsc_service_curve_t *fsc,
                                 const hfsc_service_curve_t *usc);

int              hfsc_enqueue(hfsc_scheduler_t *sched,
                               hfsc_class_t     *leaf_class,
                               struct rte_mbuf  *packet);

struct rte_mbuf *hfsc_dequeue(hfsc_scheduler_t *sched);

bool             hfsc_has_packets(hfsc_scheduler_t *sched);

void             hfsc_get_class_stats(hfsc_class_t *cl,
                                       uint64_t *packets_sent,
                                       uint64_t *bytes_sent,
                                       uint64_t *packets_dropped);

void hfsc_dump_state(hfsc_scheduler_t *sched);
void hfsc_dump_vt_state(hfsc_scheduler_t *sched);

#endif /* HFSC_SCHEDULER_H */