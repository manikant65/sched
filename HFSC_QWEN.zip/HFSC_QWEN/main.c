/********************************************************************
 * HFSC Example Application v1.5
 *
 * Compatible with hfsc_scheduler.h v2.3
 *
 * Changes in v1.5:
 *   - Fixed oversubscription (Root=101Mbps, Default=1Mbps)
 *   - All FSC.m2 ≤ USC.m2 for RT classes
 *   - Total children FSC = Root FSC (no oversubscription)
 *
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_eal.h>
#include <rte_ethdev.h>
#include <rte_mbuf.h>
#include <rte_ip.h>
#include <rte_tcp.h>
#include <rte_udp.h>
#include <rte_ether.h>
#include <rte_cycles.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

#define RX_RING_SIZE 1024
#define TX_RING_SIZE 1024
#define NUM_MBUFS 8191
#define MBUF_CACHE_SIZE 250
#define BURST_SIZE 32

/* ================================================================
 * GLOBAL STATE
 * ================================================================ */

static uint16_t rx_port = 0;
static uint16_t tx_port = 1;
static volatile bool force_quit = false;
static hfsc_scheduler_t *sched = NULL;
static bool enable_vt_dump = false;

/* Class hierarchy pointers */
static hfsc_class_t *root_class = NULL;
static hfsc_class_t *site1_class = NULL;
static hfsc_class_t *site2_class = NULL;
static hfsc_class_t *udp1_class = NULL;
static hfsc_class_t *tcp1_class = NULL;
static hfsc_class_t *udp2_class = NULL;
static hfsc_class_t *tcp2_class = NULL;
static hfsc_class_t *default_class = NULL;

/* ================================================================
 * SIGNAL HANDLING
 * ================================================================ */

static void signal_handler(int signum)
{
    if (signum == SIGINT || signum == SIGTERM) {
        printf("\n\nSignal %d received, preparing to exit...\n", signum);
        force_quit = true;
    }
}

/* ================================================================
 * PORT INITIALIZATION
 * ================================================================ */

static struct rte_eth_conf port_conf = {
    .rxmode = { .max_lro_pkt_size = RTE_ETHER_MAX_LEN },
    .txmode = { .mq_mode = RTE_ETH_MQ_TX_NONE },
};

static int port_init(uint16_t port, struct rte_mempool *mbuf_pool)
{
    struct rte_eth_conf conf = port_conf;
    const uint16_t rx_rings = 1, tx_rings = 1;
    uint16_t nb_rxd = RX_RING_SIZE;
    uint16_t nb_txd = TX_RING_SIZE;
    int retval;
    struct rte_eth_dev_info dev_info;
    
    if (!rte_eth_dev_is_valid_port(port)) {
        printf("Error: Port %u is not valid\n", port);
        return -1;
    }
    
    retval = rte_eth_dev_info_get(port, &dev_info);
    if (retval != 0) {
        printf("Error getting device info for port %u: %s\n", 
               port, strerror(-retval));
        return retval;
    }
    
    if (dev_info.rx_desc_lim.nb_max > 0 && nb_rxd > dev_info.rx_desc_lim.nb_max)
        nb_rxd = dev_info.rx_desc_lim.nb_max;
    if (dev_info.tx_desc_lim.nb_max > 0 && nb_txd > dev_info.tx_desc_lim.nb_max)
        nb_txd = dev_info.tx_desc_lim.nb_max;
    
    retval = rte_eth_dev_configure(port, rx_rings, tx_rings, &conf);
    if (retval != 0) {
        printf("Error configuring port %u: %s\n", port, strerror(-retval));
        return retval;
    }
    
    retval = rte_eth_dev_adjust_nb_rx_tx_desc(port, &nb_rxd, &nb_txd);
    if (retval != 0) {
        printf("Error adjusting descriptors for port %u: %s\n", 
               port, strerror(-retval));
        return retval;
    }
    
    retval = rte_eth_rx_queue_setup(port, 0, nb_rxd, 
                                     rte_eth_dev_socket_id(port), 
                                     NULL, mbuf_pool);
    if (retval < 0) {
        printf("Error setting up RX queue for port %u: %s\n", 
               port, strerror(-retval));
        return retval;
    }
    
    retval = rte_eth_tx_queue_setup(port, 0, nb_txd, 
                                     rte_eth_dev_socket_id(port), 
                                     NULL);
    if (retval < 0) {
        printf("Error setting up TX queue for port %u: %s\n", 
               port, strerror(-retval));
        return retval;
    }
    
    retval = rte_eth_dev_start(port);
    if (retval < 0) {
        printf("Error starting port %u: %s\n", port, strerror(-retval));
        return retval;
    }
    
    retval = rte_eth_promiscuous_enable(port);
    if (retval != 0) {
        printf("Warning: Could not enable promiscuous mode on port %u\n", port);
    }
    
    printf("Port %u initialized successfully\n", port);
    return 0;
}

/* ================================================================
 * PACKET CLASSIFICATION
 * ================================================================ */

static hfsc_class_t *classify_packet(struct rte_mbuf *m)
{
    struct rte_ether_hdr *eth_hdr;
    struct rte_ipv4_hdr *ip_hdr;
    struct rte_tcp_hdr *tcp_hdr;
    struct rte_udp_hdr *udp_hdr;
    uint16_t dst_port = 0;
    uint8_t proto;
    
    if (rte_pktmbuf_data_len(m) < sizeof(struct rte_ether_hdr) + 
                                     sizeof(struct rte_ipv4_hdr)) {
        return default_class;
    }
    
    eth_hdr = rte_pktmbuf_mtod(m, struct rte_ether_hdr *);
    
    if (eth_hdr->ether_type != rte_cpu_to_be_16(RTE_ETHER_TYPE_IPV4)) {
        return default_class;
    }
    
    ip_hdr = (struct rte_ipv4_hdr *)(eth_hdr + 1);
    proto = ip_hdr->next_proto_id;
    
    if (proto == IPPROTO_UDP) {
        if (rte_pktmbuf_data_len(m) < sizeof(struct rte_ether_hdr) + 
                                         sizeof(struct rte_ipv4_hdr) + 
                                         sizeof(struct rte_udp_hdr)) {
            return default_class;
        }
        udp_hdr = (struct rte_udp_hdr *)(ip_hdr + 1);
        dst_port = rte_be_to_cpu_16(udp_hdr->dst_port);
    } else if (proto == IPPROTO_TCP) {
        if (rte_pktmbuf_data_len(m) < sizeof(struct rte_ether_hdr) + 
                                         sizeof(struct rte_ipv4_hdr) + 
                                         sizeof(struct rte_tcp_hdr)) {
            return default_class;
        }
        tcp_hdr = (struct rte_tcp_hdr *)(ip_hdr + 1);
        dst_port = rte_be_to_cpu_16(tcp_hdr->dst_port);
    }
    
    if (proto == IPPROTO_UDP) {
        if (dst_port == 5001) return udp1_class;
        else if (dst_port == 6001) return udp2_class;
    } else if (proto == IPPROTO_TCP) {
        if (dst_port == 5002) return tcp1_class;
        else if (dst_port == 6002) return tcp2_class;
    }
    
    return default_class;
}

/* ================================================================
 * HFSC HIERARCHY SETUP
 * ================================================================ */

/*
 * Service Curve Calculations:
 *   bytes_per_sec = bits_per_sec / 8
 *   Example: 100 Mbps = 100,000,000 / 8 = 12,500,000 bytes/sec
 *
 * Hierarchy Budget (v1.5 - NO OVERSUBSCRIPTION):
 *   Root:    101 Mbps
 *   ├─ Site1: 50 Mbps
 *   ├─ Site2: 50 Mbps
 *   └─ Default: 1 Mbps
 *   ────────────────
 *   Total:   101 Mbps ✅
 */

static int setup_hfsc_hierarchy(void)
{
    hfsc_service_curve_t sc;
    
    printf("Setting up HFSC hierarchy...\n");
    
    /* ============================================================
     * ROOT: 101 Mbps (12,625,000 bytes/sec)
     * ============================================================ */
    sc = (hfsc_service_curve_t){ 
        .m1 = 12625000,  /* 101 Mbps */
        .d = 0, 
        .m2 = 12625000   /* 101 Mbps */
    };
    root_class = hfsc_create_root(sched, &sc, &sc, &sc);
    if (!root_class) { 
        printf("Failed to create root class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * SITE 1: 50 Mbps guaranteed, 60 Mbps max
     * ============================================================ */
    sc = (hfsc_service_curve_t){ 
        .m1 = 6250000,   /* 50 Mbps */
        .d = 0, 
        .m2 = 6250000    /* 50 Mbps */
    };
    site1_class = hfsc_create_class(sched, root_class, 1, false, &sc, &sc,
                                    &(hfsc_service_curve_t){ 
                                        .m1 = 7500000,  /* 60 Mbps max */
                                        .d = 0, 
                                        .m2 = 7500000 
                                    });
    if (!site1_class) { 
        printf("Failed to create site1 class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * UDP1 (Site 1): 10 Mbps RT with burst, 16 Mbps max
     *   RSC.m2 (10 Mbps) ≤ USC.m2 (16 Mbps) ✅
     * ============================================================ */
    udp1_class = hfsc_create_class(sched, site1_class, 11, true,
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 6250000,   /* 50 Mbps burst */
                                       .d = 10000,      /* 10 ms burst window */
                                       .m2 = 1250000    /* 10 Mbps sustained */
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 1250000,   /* 10 Mbps */
                                       .d = 0, 
                                       .m2 = 1250000 
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 2000000,   /* 16 Mbps cap */
                                       .d = 0, 
                                       .m2 = 2000000 
                                   });
    if (!udp1_class) { 
        printf("Failed to create udp1 class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * TCP1 (Site 1): 40 Mbps guaranteed, 48 Mbps max
     *   Site1 Total: UDP1(10) + TCP1(40) = 50 Mbps ✅
     * ============================================================ */
    tcp1_class = hfsc_create_class(sched, site1_class, 12, true,
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 5000000,   /* 40 Mbps */
                                       .d = 0, 
                                       .m2 = 5000000 
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 5000000,   /* 40 Mbps */
                                       .d = 0, 
                                       .m2 = 5000000 
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 6000000,   /* 48 Mbps cap */
                                       .d = 0, 
                                       .m2 = 6000000 
                                   });
    if (!tcp1_class) { 
        printf("Failed to create tcp1 class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * SITE 2: 50 Mbps guaranteed, 60 Mbps max
     * ============================================================ */
    sc = (hfsc_service_curve_t){ 
        .m1 = 6250000,   /* 50 Mbps */
        .d = 0, 
        .m2 = 6250000 
    };
    site2_class = hfsc_create_class(sched, root_class, 2, false, &sc, &sc,
                                    &(hfsc_service_curve_t){ 
                                        .m1 = 7500000,  /* 60 Mbps max */
                                        .d = 0, 
                                        .m2 = 7500000 
                                    });
    if (!site2_class) { 
        printf("Failed to create site2 class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * UDP2 (Site 2): 10 Mbps RT with burst, 16 Mbps max
     * ============================================================ */
    udp2_class = hfsc_create_class(sched, site2_class, 21, true,
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 6250000,   /* 50 Mbps burst */
                                       .d = 10000,      /* 10 ms burst window */
                                       .m2 = 1250000    /* 10 Mbps sustained */
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 1250000,   /* 10 Mbps */
                                       .d = 0, 
                                       .m2 = 1250000 
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 2000000,   /* 16 Mbps cap */
                                       .d = 0, 
                                       .m2 = 2000000 
                                   });
    if (!udp2_class) { 
        printf("Failed to create udp2 class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * TCP2 (Site 2): 40 Mbps guaranteed, 48 Mbps max
     *   Site2 Total: UDP2(10) + TCP2(40) = 50 Mbps ✅
     * ============================================================ */
    tcp2_class = hfsc_create_class(sched, site2_class, 22, true,
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 5000000,   /* 40 Mbps */
                                       .d = 0, 
                                       .m2 = 5000000 
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 5000000,   /* 40 Mbps */
                                       .d = 0, 
                                       .m2 = 5000000 
                                   },
                                   &(hfsc_service_curve_t){ 
                                       .m1 = 6000000,   /* 48 Mbps cap */
                                       .d = 0, 
                                       .m2 = 6000000 
                                   });
    if (!tcp2_class) { 
        printf("Failed to create tcp2 class\n"); 
        return -1; 
    }
    
    /* ============================================================
     * DEFAULT: 1 Mbps best effort (FIXED from 10 Mbps)
     * ============================================================ */
    default_class = hfsc_create_class(sched, root_class, 99, true, NULL,
                                      &(hfsc_service_curve_t){ 
                                          .m1 = 125000,    /* 1 Mbps */
                                          .d = 0, 
                                          .m2 = 125000 
                                      },
                                      NULL);
    if (!default_class) { 
        printf("Failed to create default class\n"); 
        return -1; 
    }
    
    printf("\nHFSC hierarchy created successfully (v1.5):\n");
    printf("┌─────────────────────────────────────────────────────────┐\n");
    printf("│ ROOT (101 Mbps)                                         │\n");
    printf("│  ├─ SITE1 (50 Mbps guaranteed, 60 Mbps max)             │\n");
    printf("│  │   ├─ UDP1 (10 Mbps RT + 50Mbps/10ms burst, 16M cap)  │\n");
    printf("│  │   └─ TCP1 (40 Mbps guaranteed, 48 Mbps max)          │\n");
    printf("│  ├─ SITE2 (50 Mbps guaranteed, 60 Mbps max)             │\n");
    printf("│  │   ├─ UDP2 (10 Mbps RT + 50Mbps/10ms burst, 16M cap)  │\n");
    printf("│  │   └─ TCP2 (40 Mbps guaranteed, 48 Mbps max)          │\n");
    printf("│  └─ DEFAULT (1 Mbps best effort)                        │\n");
    printf("├─────────────────────────────────────────────────────────┤\n");
    printf("│ Total Children FSC: 50 + 50 + 1 = 101 Mbps ✅           │\n");
    printf("│ Root FSC: 101 Mbps ✅ (NO OVERSUBSCRIPTION)             │\n");
    printf("└─────────────────────────────────────────────────────────┘\n\n");
    
    return 0;
}

/* ================================================================
 * STATISTICS PRINTING
 * ================================================================ */

static void print_stats(void)
{
    uint64_t packets, bytes, drops;
    
    printf("\n╔════════════════════════════════════════════════════════╗\n");
    printf("║           HFSC Statistics (v1.5)                       ║\n");
    printf("╠════════════════════════════════════════════════════════╣\n");
    
    printf("║ UDP1 (RT):   ");
    hfsc_get_class_stats(udp1_class, &packets, &bytes, &drops);
    printf("TX: %8lu pkts (%6lu MB), Drops: %5lu  ║\n", 
           packets, bytes / 1000000, drops);
    
    printf("║ TCP1 (Bulk): ");
    hfsc_get_class_stats(tcp1_class, &packets, &bytes, &drops);
    printf("TX: %8lu pkts (%6lu MB), Drops: %5lu  ║\n", 
           packets, bytes / 1000000, drops);
    
    printf("║ UDP2 (RT):   ");
    hfsc_get_class_stats(udp2_class, &packets, &bytes, &drops);
    printf("TX: %8lu pkts (%6lu MB), Drops: %5lu  ║\n", 
           packets, bytes / 1000000, drops);
    
    printf("║ TCP2 (Bulk): ");
    hfsc_get_class_stats(tcp2_class, &packets, &bytes, &drops);
    printf("TX: %8lu pkts (%6lu MB), Drops: %5lu  ║\n", 
           packets, bytes / 1000000, drops);
    
    printf("║ DEFAULT:     ");
    hfsc_get_class_stats(default_class, &packets, &bytes, &drops);
    printf("TX: %8lu pkts (%6lu MB), Drops: %5lu  ║\n", 
           packets, bytes / 1000000, drops);
    
    printf("╚════════════════════════════════════════════════════════╝\n");
}

/* ================================================================
 * MAIN PACKET PROCESSING LOOP
 * ================================================================ */

static void lcore_main(uint16_t rx_port, uint16_t tx_port)
{
    struct rte_mbuf *rx_bufs[BURST_SIZE];
    struct rte_mbuf *tx_bufs[BURST_SIZE];
    uint16_t nb_rx, nb_tx, tx_count;
    hfsc_class_t *cl;
    uint64_t next_stats = 0;
    uint64_t next_vt_dump = 0;
    uint64_t tsc_hz = rte_get_tsc_hz();
    
    printf("Core %u starting packet processing (v1.5)\n", rte_lcore_id());
    printf("  RX Port: %u  TX Port: %u\n", rx_port, tx_port);
    printf("  VT Dump: %s\n", enable_vt_dump ? "enabled (10s)" : "disabled");
    printf("  Press Ctrl+C to exit\n\n");
    
    while (!force_quit) {
        nb_rx = rte_eth_rx_burst(rx_port, 0, rx_bufs, BURST_SIZE);
        
        for (uint16_t i = 0; i < nb_rx; i++) {
            cl = classify_packet(rx_bufs[i]);
            if (hfsc_enqueue(sched, cl, rx_bufs[i]) < 0) {
                rte_pktmbuf_free(rx_bufs[i]);
            }
        }
        
        tx_count = 0;
        while (tx_count < BURST_SIZE && hfsc_has_packets(sched)) {
            tx_bufs[tx_count] = hfsc_dequeue(sched);
            if (tx_bufs[tx_count] == NULL) break;
            tx_count++;
        }
        
        if (tx_count > 0) {
            nb_tx = rte_eth_tx_burst(tx_port, 0, tx_bufs, tx_count);
            
            for (uint16_t i = nb_tx; i < tx_count; i++) {
                rte_pktmbuf_free(tx_bufs[i]);
            }
        }
        
        uint64_t now = rte_get_tsc_cycles();
        if (now > next_stats) {
            print_stats();
            next_stats = now + (tsc_hz * 5);
        }
        
        if (enable_vt_dump && now > next_vt_dump) {
            hfsc_dump_vt_state(sched);
            next_vt_dump = now + (tsc_hz * 10);
        }
    }
    
    print_stats();
    printf("\nShutting down packet processing...\n");
}

/* ================================================================
 * COMMAND-LINE PARSING
 * ================================================================ */

static void print_usage(const char *prog_name)
{
    printf("Usage: %s [EAL args] -- --rx-port=<N> --tx-port=<N> [--vt-dump]\n", 
           prog_name);
    printf("\nOptions:\n");
    printf("  --rx-port=<N>    RX port ID (default: 0)\n");
    printf("  --tx-port=<N>    TX port ID (default: 1)\n");
    printf("  --vt-dump        Enable periodic VT state dump\n");
    printf("\nExample:\n");
    printf("  %s -l 0-3 -n 4 -- --rx-port=0 --tx-port=1 --vt-dump\n", 
           prog_name);
}

static int parse_app_args(int argc, char *argv[])
{
    int opt;
    char *end;
    
    static struct option lgopts[] = {
        { "rx-port", required_argument, 0, 0 },
        { "tx-port", required_argument, 0, 0 },
        { "vt-dump", no_argument, 0, 0 },
        { NULL, 0, 0, 0 }
    };
    
    optind = 1;
    
    while ((opt = getopt_long(argc, argv, "", lgopts, NULL)) != -1) {
        switch (opt) {
        case 0:
            if (strcmp(lgopts[optind - 1].name, "rx-port") == 0) {
                rx_port = strtol(optarg, &end, 10);
                if (*end != '\0') {
                    printf("Invalid RX port: %s\n", optarg);
                    return -1;
                }
            } else if (strcmp(lgopts[optind - 1].name, "tx-port") == 0) {
                tx_port = strtol(optarg, &end, 10);
                if (*end != '\0') {
                    printf("Invalid TX port: %s\n", optarg);
                    return -1;
                }
            } else if (strcmp(lgopts[optind - 1].name, "vt-dump") == 0) {
                enable_vt_dump = true;
            }
            break;
        default:
            return -1;
        }
    }
    
    return 0;
}

/* ================================================================
 * MAIN ENTRY POINT
 * ================================================================ */

int main(int argc, char *argv[])
{
    struct rte_mempool *mbuf_pool = NULL;
    unsigned nb_ports_available = 0;
    uint16_t portid;
    int ret;
    
    ret = rte_eal_init(argc, argv);
    if (ret < 0) {
        rte_exit(EXIT_FAILURE, "Error with EAL initialization\n");
    }
    
    argc -= ret;
    argv += ret;
    
    if (parse_app_args(argc, argv) < 0) {
        print_usage(argv[0]);
        rte_eal_cleanup();
        return EXIT_FAILURE;
    }
    
    nb_ports = rte_eth_dev_count_avail();
    if (nb_ports < 2) {
        rte_exit(EXIT_FAILURE, "Error: need at least 2 ports (found %u)\n", 
                 nb_ports);
    }
    
    if (!rte_cycles_has_invariant_tsc()) {
        printf("WARNING: TSC is not invariant! Multi-core may have timing issues.\n");
    }
    
    mbuf_pool = rte_pktmbuf_pool_create("MBUF_POOL", 
                                         NUM_MBUFS * nb_ports,
                                         MBUF_CACHE_SIZE, 
                                         0,
                                         RTE_MBUF_DEFAULT_BUF_SIZE,
                                         rte_socket_id());
    if (mbuf_pool == NULL) {
        rte_exit(EXIT_FAILURE, "Cannot create mbuf pool\n");
    }
    printf("Mbuf pool created successfully\n");
    
    if (hfsc_init(&sched) < 0) {
        rte_exit(EXIT_FAILURE, "Failed to initialize HFSC scheduler\n");
    }
    printf("HFSC scheduler initialized\n");
    
    if (setup_hfsc_hierarchy() < 0) {
        rte_exit(EXIT_FAILURE, "Failed to setup HFSC hierarchy\n");
    }
    
    RTE_ETH_FOREACH_DEV(portid) {
        if (portid == rx_port || portid == tx_port) {
            if (port_init(portid, mbuf_pool) != 0) {
                rte_exit(EXIT_FAILURE, "Cannot init port %u\n", portid);
            }
            nb_ports_available++;
        }
    }
    
    if (nb_ports_available < 2) {
        rte_exit(EXIT_FAILURE, "Not enough available ports (need RX + TX)\n");
    }
    
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    lcore_main(rx_port, tx_port);
    
    printf("\nCleaning up...\n");
    
    RTE_ETH_FOREACH_DEV(portid) {
        printf("Stopping port %u... ", portid);
        rte_eth_dev_stop(portid);
        printf("Done\n");
    }
    
    RTE_ETH_FOREACH_DEV(portid) {
        printf("Closing port %u... ", portid);
        rte_eth_dev_close(portid);
        printf("Done\n");
    }
    
    printf("Cleaning up HFSC scheduler... ");
    hfsc_cleanup(sched);
    printf("Done\n");
    
    printf("Cleaning up EAL... ");
    rte_eal_cleanup();
    printf("Done\n");
    
    printf("\nBye!\n");
    return 0;
}

/*

# Set DPDK environment
export RTE_SDK=/path/to/dpdk
export RTE_TARGET=x86_64-native-linuxapp-gcc

# Compile
gcc -O3 -march=native \
    -I$RTE_SDK/include \
    -L$RTE_SDK/build/lib \
    -Wl,-rpath=$RTE_SDK/build/lib \
    -o hfsc_app main.c hfsc_scheduler.c \
    -ldpdk -lpthread -lnuma

# Run (basic)
sudo ./hfsc_app -l 0-3 -n 4 -- --rx-port=0 --tx-port=1

# Run (with VT dump for debugging)
sudo ./hfsc_app -l 0-3 -n 4 -- --rx-port=0 --tx-port=1 --vt-dump

# Test traffic (from another machine)
# UDP RT traffic (port 5001)
iperf3 -u -c <router_ip> -p 5001 -b 10M

# TCP bulk traffic (port 5002)
iperf3 -c <router_ip> -p 5002 -b 0


RSC.m2 ≤ USC.m2 (Recommended)
*/