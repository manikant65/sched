/********************************************************************
 * hfsc_scheduler.h — Hierarchical Fair Service Curve Scheduler v2.2
 *
 * References:
 *   [1] Stoica et al., "A Hierarchical Fair Service Curve Algorithm
 *       for Link-Sharing, Real-Time and Priority Service"
 *       IEEE/ACM Transactions on Networking, 1997.
 *   [2] Linux kernel net/sched/sch_hfsc.c
 *
 * ---------------------------------------------------------------
 * OVERVIEW
 * ---------------------------------------------------------------
 *
 * Three service curves per class:
 *
 *   RSC  Real-time Service Curve  — hard per-class bandwidth guarantee.
 *        Uses EDF (earliest deadline first) among eligible leaf classes.
 *        cl_e = eligible_curve^{-1}(cumul)      — when class becomes eligible
 *        cl_d = rsc^{-1}(cumul + next_pkt_len)  — when next packet is due
 *
 *   FSC  Fair-Share Service Curve — proportional link-sharing.
 *        cl_vt = fsc^{-1}(total) + vt_offset   — virtual time
 *        Scheduler picks the active class with the smallest cl_vt,
 *        recursing from root down to a leaf.
 *
 *   USC  Upper-limit Service Curve — bandwidth cap (LS path only).
 *        cl_myf = usc^{-1}(total)               — fit-time (earliest send)
 *        USC does NOT restrict the RT path.
 *
 * Service curve S(t) — two-piece linear:
 *   S(t) = m1 * t                   for  0 ≤ t ≤ d
 *   S(t) = m1*d + m2*(t − d)        for  t > d
 *
 * Internally stored as a running segment anchored at (cl_x, cl_y)
 * and re-anchored ("rewound") after every packet served.
 * Slopes are HFSC_FIXEDPOINT_SHIFT-bit fixed-point bytes/cycle.
 *
 * Virtual-time fairness on re-activation (Section 4.3 of [1]):
 *   Each deactivation increments deactivation_generation.
 *   On re-activation, if the generation changed, vt_offset snaps
 *   cl_vt to max(raw_vt, parent->cl_cvtmin) so an idle class
 *   cannot undercut siblings that stayed active.
 *
 ********************************************************************/

#ifndef HFSC_SCHEDULER_H
#define HFSC_SCHEDULER_H

#include <stdint.h>
#include <stdbool.h>
#include <rte_mbuf.h>
#include <rte_ring.h>
#include <rte_cycles.h>

/* ----------------------------------------------------------------
 * Compile-time limits
 * ---------------------------------------------------------------- */
#define HFSC_MAX_CLASSES        256    /* total classes in the hierarchy    */
#define HFSC_MAX_CHILDREN       32     /* max children per interior node    */
#define HFSC_QUEUE_SIZE         8192   /* per-leaf ring size (power of 2)   */

/**
 * HFSC_FIXEDPOINT_SHIFT — fractional bits in slope values.
 * slope = (rate_bytes_per_sec << SHIFT) / tsc_cycles_per_second
 * 24 bits: sub-nanosecond precision at 3 GHz, no 64-bit overflow
 * for intervals up to ~1 second.
 */
#define HFSC_FIXEDPOINT_SHIFT   24


/* ================================================================
 * USER-FACING SERVICE CURVE
 * ================================================================ */

/**
 * hfsc_service_curve_t — two-piece linear service curve.
 *
 * Constant rate:   m1 = m2, d = 0
 * Burst then rate: m1 > m2, d = burst window in microseconds
 */
typedef struct {
    uint64_t m1;  /* initial slope    (bytes/sec)    */
    uint64_t d;   /* burst window     (microseconds) */
    uint64_t m2;  /* sustained slope  (bytes/sec)    */
} hfsc_service_curve_t;


/* ================================================================
 * INTERNAL RUNTIME CURVE SEGMENT
 * ================================================================ */

/**
 * hfsc_internal_curve_t — running two-piece linear segment.
 *
 * Anchored at (cl_x, cl_y):
 *   bytes(t) = cl_y + slope_initial   * (t − cl_x)
 *                        for t ∈ [cl_x,  cl_x + burst_duration]
 *   bytes(t) = cl_y + burst_bytes
 *              + slope_sustained * (t − cl_x − burst_duration)
 *                        for t >  cl_x + burst_duration
 *
 * slope_initial / slope_sustained: fixed-point bytes/cycle
 *   = (bytes_per_sec << HFSC_FIXEDPOINT_SHIFT) / tsc_hz
 */
typedef struct {
    uint64_t cl_x;            /* anchor time   (TSC cycles)              */
    uint64_t cl_y;            /* anchor bytes  (cumulative at cl_x)      */
    uint64_t burst_duration;  /* initial-segment length (TSC cycles)     */
    uint64_t burst_bytes;     /* bytes delivered in the initial segment  */
    uint64_t slope_initial;   /* initial slope  (fixed-point bytes/cycle)*/
    uint64_t slope_sustained; /* sustained slope (fixed-point bytes/cycle)*/
} hfsc_internal_curve_t;


/* ================================================================
 * TRAFFIC CLASS
 * ================================================================ */

typedef struct hfsc_class hfsc_class_t;

/**
 * hfsc_class_t — one node in the HFSC class hierarchy.
 *
 * Interior nodes: no queue, compete via their own FSC/cl_vt.
 * Leaf nodes:     hold a packet queue, are directly transmitted.
 */
struct hfsc_class {

    /* ---- Hierarchy ---- */
    hfsc_class_t  *parent;
    hfsc_class_t  *children[HFSC_MAX_CHILDREN];
    uint32_t       num_children;
    uint32_t       class_id;
    bool           is_leaf;

    /* ---- Packet queue (leaf only) ---- */
    struct rte_ring *queue;
    uint32_t         qlen;    /* packets in queue   */
    uint64_t         qbytes;  /* bytes in queue     */

    /* ---- User service curves ---- */
    hfsc_service_curve_t rsc;      /* real-time curve   */
    hfsc_service_curve_t fsc;      /* fair-share curve  */
    hfsc_service_curve_t usc;      /* upper-limit curve */
    bool has_rsc;
    bool has_usc;

    /* ---- Runtime curves (re-anchored after every packet) ---- */
    hfsc_internal_curve_t rt_deadline_curve;      /* RSC running segment  */
    hfsc_internal_curve_t ls_virtual_time_curve;  /* FSC running segment  */
    hfsc_internal_curve_t ul_fittime_curve;       /* USC running segment  */
    hfsc_internal_curve_t rt_eligible_curve;      /* concave hull of RSC  */

    /* ---- Byte counters ---- */
    uint64_t cumul;   /* bytes served — used by RSC/eligible inverses (RT) */
    uint64_t total;   /* bytes served — used by FSC/USC inverses  (LS/USC) */

    /* ---- RT scheduling state ---- */
    uint64_t cl_e;               /* eligible time (TSC)  */
    uint64_t cl_d;               /* deadline time (TSC)  */
    int      deadline_heap_index;/* position in RT heap, -1 if absent */

    /* ---- LS scheduling state ---- */
    uint64_t cl_vt;     /* virtual time = FSC^{-1}(total) + vt_offset */
    uint64_t vt_offset; /* snap offset applied on re-activation        */

    /**
     * deactivation_generation: incremented every time this class is
     * deactivated.  Compared against saved_parent_generation on the
     * next activation to detect a new period.
     */
    uint32_t deactivation_generation;

    /**
     * saved_parent_generation: snapshot of THIS class's own
     * deactivation_generation taken at the last activation.
     * Mismatch on re-activation => new period => recompute vt_offset.
     */
    uint32_t saved_parent_generation;

    /* ---- USC state ---- */
    uint64_t cl_myf;   /* fit-time: 0 = not restricted */

    /* ---- Children VT range (interior nodes) ---- */
    uint64_t cl_cvtmin;  /* min cl_vt of active children  */
    uint64_t cl_cvtmax;  /* max cl_vt of active children  */

    /* ---- Liveness ---- */
    bool is_active;

    /* ---- Per-class statistics ---- */
    uint64_t stat_packets_sent;
    uint64_t stat_bytes_sent;
    uint64_t stat_packets_dropped;
};


/* ================================================================
 * SCHEDULER
 * ================================================================ */

typedef struct {
    hfsc_class_t   *root_class;
    hfsc_class_t   *all_classes[HFSC_MAX_CLASSES];
    uint32_t        num_classes;

    hfsc_class_t  **rt_deadline_heap;   /* min-heap by cl_d */
    uint32_t        rt_heap_size;
    uint32_t        rt_heap_capacity;

    uint64_t tsc_cycles_per_second;

    uint64_t total_packets_enqueued;
    uint64_t total_packets_dequeued;
    uint64_t total_packets_dropped;
} hfsc_scheduler_t;


/* ================================================================
 * PUBLIC API
 * ================================================================ */

int  hfsc_init(hfsc_scheduler_t **sched_out);
void hfsc_cleanup(hfsc_scheduler_t *sched);

hfsc_class_t *hfsc_create_root(hfsc_scheduler_t          *sched,
                                const hfsc_service_curve_t *rsc,
                                const hfsc_service_curve_t *fsc,
                                const hfsc_service_curve_t *usc);

/**
 * hfsc_create_class — create an interior or leaf class.
 *  rsc  NULL → no RT guarantee
 *  fsc  required, m2 must be > 0
 *  usc  NULL → no bandwidth cap
 */
hfsc_class_t *hfsc_create_class(hfsc_scheduler_t          *sched,
                                 hfsc_class_t              *parent,
                                 uint32_t                   class_id,
                                 bool                       is_leaf,
                                 const hfsc_service_curve_t *rsc,
                                 const hfsc_service_curve_t *fsc,
                                 const hfsc_service_curve_t *usc);

int              hfsc_enqueue(hfsc_scheduler_t *sched,
                               hfsc_class_t     *leaf_class,
                               struct rte_mbuf  *packet);

struct rte_mbuf *hfsc_dequeue(hfsc_scheduler_t *sched);

bool             hfsc_has_packets(hfsc_scheduler_t *sched);

void             hfsc_get_class_stats(hfsc_class_t *cl,
                                       uint64_t *packets_sent,
                                       uint64_t *bytes_sent,
                                       uint64_t *packets_dropped);

void hfsc_dump_state(hfsc_scheduler_t *sched);
void hfsc_dump_vt_state(hfsc_scheduler_t *sched);

#endif /* HFSC_SCHEDULER_H */
