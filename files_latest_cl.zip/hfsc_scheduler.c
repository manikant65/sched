/********************************************************************
 * hfsc_scheduler.c — Hierarchical Fair Service Curve Scheduler v2.2
 *
 * References:
 *   [1] Stoica et al., "A Hierarchical Fair Service Curve Algorithm
 *       for Link-Sharing, Real-Time and Priority Service"
 *       IEEE/ACM Transactions on Networking, 1997.
 *   [2] Linux kernel net/sched/sch_hfsc.c
 *
 * Naming convention:
 *   Public struct fields keep standard HFSC/Linux names
 *   (rsc, fsc, usc, cl_vt, cl_d, cl_e, cl_myf, cumul, total …).
 *   All local variables and static helpers use full English names.
 *
 * Bug fixes vs v2.1:
 *   Fix 1: ls_update_virtual_time_and_propagate — removed the
 *           erroneous double refresh_children_vt_range(ancestor->parent)
 *           call inside the loop.  Ancestor VT updates are now done
 *           entirely in the dequeue ancestor-propagation loop so there
 *           is one clear code path for interior node state.
 *
 *   Fix 2: class_activate — vt_offset accumulation bug fixed.
 *           vt_offset is now explicitly reset to 0 before the
 *           conditional snap so stale values from a prior period
 *           never carry forward.
 *
 *   Fix 3: class_activate — the "new period" detection used the
 *           wrong counter name (old code compared deactivation_generation
 *           against parent_generation_at_last_activation but the latter
 *           was tracking the class's own generation, not the parent's).
 *           Renamed to saved_parent_generation, semantics made explicit:
 *           both fields live on the same class; mismatch == new period.
 *
 *   Fix 4: scheduler_pick_linkshare_class — USC check on the node
 *           passed in is skipped for the root class (root never has USC
 *           in practice; checking it could silently block all LS traffic).
 *
 *   Fix 5: hfsc_dequeue — ls_update_virtual_time_and_propagate now
 *           only updates the leaf's own cl_vt.  The ancestor propagation
 *           loop that follows handles all interior-node cl_vt and
 *           cl_cvtmin/max updates in one well-defined pass.
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_malloc.h>
#include <rte_log.h>
#include <string.h>
#include <stdio.h>

#define RTE_LOGTYPE_HFSC RTE_LOGTYPE_USER1
#define HFSC_LOG(level, fmt, ...) \
    RTE_LOG(level, HFSC, "[HFSC] " fmt, ##__VA_ARGS__)


/* ================================================================
 * SECTION 1 — FIXED-POINT ARITHMETIC HELPERS
 * ================================================================ */

/**
 * convert_rate_to_fixedpoint_slope — bytes/sec → fixed-point bytes/cycle.
 * Uses 128-bit arithmetic to avoid overflow during the shift+divide.
 * Returns at least 1 for any non-zero rate.
 */
static inline uint64_t
convert_rate_to_fixedpoint_slope(uint64_t rate_bytes_per_sec,
                                 uint64_t tsc_cycles_per_second)
{
    if (rate_bytes_per_sec == 0)
        return 0;

    __uint128_t shifted = (__uint128_t)rate_bytes_per_sec
                          << HFSC_FIXEDPOINT_SHIFT;
    uint64_t slope = (uint64_t)(shifted / tsc_cycles_per_second);
    return (slope > 0) ? slope : 1;
}

/**
 * convert_microseconds_to_tsc_cycles — μs → TSC cycles.
 */
static inline uint64_t
convert_microseconds_to_tsc_cycles(uint64_t duration_us,
                                   uint64_t tsc_cycles_per_second)
{
    return (duration_us * tsc_cycles_per_second) / 1000000ULL;
}


/* ================================================================
 * SECTION 2 — CURVE EVALUATION (FORWARD AND INVERSE)
 * ================================================================ */

/**
 * curve_eval_forward — S(t): TSC timestamp → cumulative bytes.
 *
 *   bytes(t) = cl_y + slope_initial   * (t − cl_x)
 *                    for t ∈ [cl_x, cl_x + burst_duration]
 *   bytes(t) = cl_y + burst_bytes
 *              + slope_sustained * (t − cl_x − burst_duration)
 *                    for t >  cl_x + burst_duration
 */
static inline uint64_t
curve_eval_forward(const hfsc_internal_curve_t *curve, uint64_t query_time)
{
    if (query_time <= curve->cl_x)
        return curve->cl_y;

    uint64_t elapsed = query_time - curve->cl_x;

    if (elapsed <= curve->burst_duration) {
        return curve->cl_y
               + (uint64_t)(((__uint128_t)elapsed * curve->slope_initial)
                            >> HFSC_FIXEDPOINT_SHIFT);
    }

    uint64_t tail_elapsed = elapsed - curve->burst_duration;
    return curve->cl_y + curve->burst_bytes
           + (uint64_t)(((__uint128_t)tail_elapsed * curve->slope_sustained)
                        >> HFSC_FIXEDPOINT_SHIFT);
}

/**
 * curve_eval_inverse — S⁻¹(y): cumulative bytes → TSC timestamp.
 * Returns UINT64_MAX when slope_sustained == 0 (target unreachable).
 */
static inline uint64_t
curve_eval_inverse(const hfsc_internal_curve_t *curve, uint64_t query_bytes)
{
    if (query_bytes <= curve->cl_y)
        return curve->cl_x;

    uint64_t bytes_above_anchor = query_bytes - curve->cl_y;

    if (bytes_above_anchor <= curve->burst_bytes) {
        /* Target is inside the initial (burst) segment. */
        if (curve->slope_initial == 0)
            return curve->cl_x + curve->burst_duration;

        return curve->cl_x
               + (uint64_t)(((__uint128_t)bytes_above_anchor
                              << HFSC_FIXEDPOINT_SHIFT)
                             / curve->slope_initial);
    }

    /* Target is in the sustained segment. */
    if (curve->slope_sustained == 0)
        return UINT64_MAX;

    uint64_t bytes_into_tail = bytes_above_anchor - curve->burst_bytes;
    return curve->cl_x + curve->burst_duration
           + (uint64_t)(((__uint128_t)bytes_into_tail
                          << HFSC_FIXEDPOINT_SHIFT)
                         / curve->slope_sustained);
}


/* ================================================================
 * SECTION 3 — CURVE INITIALISATION AND RE-ANCHORING
 * ================================================================ */

/**
 * curve_segment_init — anchor a fresh curve at (anchor_time, anchor_bytes).
 * Always writes every field.  Used on class creation and on (re-)activation
 * for RT curves where a clean reset is required.
 */
static void
curve_segment_init(hfsc_internal_curve_t      *curve,
                   const hfsc_service_curve_t *user_spec,
                   uint64_t                    anchor_time,
                   uint64_t                    anchor_bytes,
                   uint64_t                    tsc_hz)
{
    curve->cl_x = anchor_time;
    curve->cl_y = anchor_bytes;

    if (user_spec == NULL || (user_spec->m1 == 0 && user_spec->m2 == 0)) {
        curve->slope_initial   = 0;
        curve->slope_sustained = 0;
        curve->burst_duration  = 0;
        curve->burst_bytes     = 0;
        return;
    }

    curve->slope_initial   = convert_rate_to_fixedpoint_slope(
                                 user_spec->m1, tsc_hz);
    curve->slope_sustained = convert_rate_to_fixedpoint_slope(
                                 user_spec->m2, tsc_hz);
    curve->burst_duration  = convert_microseconds_to_tsc_cycles(
                                 user_spec->d, tsc_hz);
    curve->burst_bytes     = (uint64_t)(
                                 ((__uint128_t)curve->burst_duration
                                  * curve->slope_initial)
                                 >> HFSC_FIXEDPOINT_SHIFT);
}

/**
 * curve_segment_reanchor — move the anchor to (now, bytes_served) after
 * a packet is transmitted, preserving the burst shape where possible.
 * Matches Linux hfsc_updatesc().
 *
 * CRITICAL: always writes cl_x.  A stale cl_x causes curve_eval_inverse
 * to return times relative to TSC epoch 0 — billions of cycles in the
 * past — making deadlines and virtual times completely wrong.
 *
 * m1 <= m2 (concave / constant rate):
 *   Re-anchor unconditionally with the full user-specified shape.
 *
 * m1 > m2 (convex / burst):
 *   bytes_at_end_of_burst = what the OLD curve delivers at (now + burst).
 *   If <= bytes_served + new burst bytes: burst exhausted → pure m2 slope.
 *   Else: compute remaining burst duration and re-anchor with shorter burst.
 */
static void
curve_segment_reanchor(hfsc_internal_curve_t      *curve,
                       const hfsc_service_curve_t *user_spec,
                       uint64_t                    now,
                       uint64_t                    bytes_served,
                       uint64_t                    tsc_hz)
{
    if (user_spec == NULL || (user_spec->m1 == 0 && user_spec->m2 == 0))
        return;

    uint64_t new_slope_initial   = convert_rate_to_fixedpoint_slope(
                                       user_spec->m1, tsc_hz);
    uint64_t new_slope_sustained = convert_rate_to_fixedpoint_slope(
                                       user_spec->m2, tsc_hz);
    uint64_t new_burst_duration  = convert_microseconds_to_tsc_cycles(
                                       user_spec->d, tsc_hz);
    uint64_t new_burst_bytes     = (uint64_t)(
                                       ((__uint128_t)new_burst_duration
                                        * new_slope_initial)
                                       >> HFSC_FIXEDPOINT_SHIFT);

    if (new_slope_initial <= new_slope_sustained) {
        /* Concave/constant case — always re-anchor with full shape. */
        curve->cl_x            = now;
        curve->cl_y            = bytes_served;
        curve->slope_initial   = new_slope_initial;
        curve->slope_sustained = new_slope_sustained;
        curve->burst_duration  = new_burst_duration;
        curve->burst_bytes     = new_burst_bytes;

    } else {
        /*
         * Convex/burst case.
         * Check how much burst remains by evaluating the OLD curve
         * at (now + new_burst_duration).
         */
        uint64_t bytes_at_end_of_burst =
            curve_eval_forward(curve, now + new_burst_duration);

        if (bytes_at_end_of_burst <= bytes_served + new_burst_bytes) {
            /* Burst exhausted — switch to pure sustained slope. */
            curve->cl_x            = now;
            curve->cl_y            = bytes_served;
            curve->slope_initial   = new_slope_sustained;
            curve->slope_sustained = new_slope_sustained;
            curve->burst_duration  = 0;
            curve->burst_bytes     = 0;

        } else {
            /*
             * Burst partially remains.
             * remaining_burst_bytes = area above the sustained line
             * that still needs to be delivered.
             * remaining_burst_duration = remaining_burst_bytes
             *                           / (slope_initial - slope_sustained)
             */
            uint64_t remaining_burst_bytes =
                bytes_at_end_of_burst - bytes_served - new_burst_bytes;
            uint64_t slope_excess =
                new_slope_initial - new_slope_sustained;
            uint64_t remaining_burst_duration =
                (slope_excess > 0)
                ? (uint64_t)(((__uint128_t)remaining_burst_bytes
                               << HFSC_FIXEDPOINT_SHIFT)
                              / slope_excess)
                : new_burst_duration;

            if (remaining_burst_duration > new_burst_duration)
                remaining_burst_duration = new_burst_duration;

            curve->cl_x            = now;
            curve->cl_y            = bytes_served;
            curve->slope_initial   = new_slope_initial;
            curve->slope_sustained = new_slope_sustained;
            curve->burst_duration  = remaining_burst_duration;
            curve->burst_bytes     = (uint64_t)(
                                         ((__uint128_t)remaining_burst_duration
                                          * new_slope_initial)
                                         >> HFSC_FIXEDPOINT_SHIFT);
        }
    }
}

/**
 * build_eligible_curve_from_rsc — derive the eligible curve as the
 * lower concave hull of the RT deadline curve.
 *
 * When m1 > m2 (burst): concave hull = m2-rate line from same anchor.
 * When m1 <= m2: RSC is already concave, so eligible == RSC.
 *
 * Call AFTER rt_deadline_curve has been initialised or re-anchored.
 */
static void
build_eligible_curve_from_rsc(hfsc_internal_curve_t       *eligible,
                               const hfsc_internal_curve_t *rt_deadline,
                               const hfsc_service_curve_t  *user_rsc)
{
    *eligible = *rt_deadline; /* copy anchor and both slopes */

    if (user_rsc != NULL && user_rsc->m1 > user_rsc->m2) {
        /* Collapse burst: eligible = pure sustained-slope line. */
        eligible->slope_initial  = eligible->slope_sustained;
        eligible->burst_duration = 0;
        eligible->burst_bytes    = 0;
    }
}


/* ================================================================
 * SECTION 4 — RT DEADLINE MIN-HEAP
 *
 * Active RT leaf classes in a min-heap keyed by cl_d.
 * Each class stores its own heap position (deadline_heap_index) for
 * O(log n) remove and reposition without a search.
 * ================================================================ */

static inline void
deadline_heap_swap(hfsc_class_t **heap, int pos_a, int pos_b)
{
    hfsc_class_t *tmp    = heap[pos_a];
    heap[pos_a]          = heap[pos_b];
    heap[pos_b]          = tmp;
    heap[pos_a]->deadline_heap_index = pos_a;
    heap[pos_b]->deadline_heap_index = pos_b;
}

static void
deadline_heap_sift_up(hfsc_class_t **heap, int position)
{
    while (position > 0) {
        int parent_pos = (position - 1) >> 1;
        if (heap[position]->cl_d >= heap[parent_pos]->cl_d)
            break;
        deadline_heap_swap(heap, position, parent_pos);
        position = parent_pos;
    }
}

static void
deadline_heap_sift_down(hfsc_class_t **heap, int heap_size, int position)
{
    for (;;) {
        int left  = 2 * position + 1;
        int right = 2 * position + 2;
        int smallest = position;

        if (left  < heap_size && heap[left]->cl_d  < heap[smallest]->cl_d)
            smallest = left;
        if (right < heap_size && heap[right]->cl_d < heap[smallest]->cl_d)
            smallest = right;

        if (smallest == position)
            break;

        deadline_heap_swap(heap, position, smallest);
        position = smallest;
    }
}

static void
deadline_heap_insert(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->deadline_heap_index >= 0)
        return; /* already present */
    if (sched->rt_heap_size >= sched->rt_heap_capacity) {
        HFSC_LOG(ERR, "RT deadline heap is full\n");
        return;
    }
    int pos = sched->rt_heap_size++;
    sched->rt_deadline_heap[pos] = cl;
    cl->deadline_heap_index = pos;
    deadline_heap_sift_up(sched->rt_deadline_heap, pos);
}

static void
deadline_heap_remove(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    int removed_pos = cl->deadline_heap_index;
    if (removed_pos < 0)
        return;

    cl->deadline_heap_index = -1;

    int last_pos = --sched->rt_heap_size;
    if (removed_pos == last_pos)
        return; /* was the last entry */

    /* Fill the hole with the last entry and restore heap order. */
    sched->rt_deadline_heap[removed_pos] = sched->rt_deadline_heap[last_pos];
    sched->rt_deadline_heap[removed_pos]->deadline_heap_index = removed_pos;

    int parent_pos = (removed_pos - 1) >> 1;
    if (removed_pos > 0
        && sched->rt_deadline_heap[removed_pos]->cl_d
           < sched->rt_deadline_heap[parent_pos]->cl_d)
        deadline_heap_sift_up(sched->rt_deadline_heap, removed_pos);
    else
        deadline_heap_sift_down(sched->rt_deadline_heap,
                                 sched->rt_heap_size, removed_pos);
}

static void
deadline_heap_reposition(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    int pos = cl->deadline_heap_index;
    if (pos < 0)
        return;

    int parent_pos = (pos - 1) >> 1;
    if (pos > 0 && cl->cl_d < sched->rt_deadline_heap[parent_pos]->cl_d)
        deadline_heap_sift_up(sched->rt_deadline_heap, pos);
    else
        deadline_heap_sift_down(sched->rt_deadline_heap,
                                 sched->rt_heap_size, pos);
}


/* ================================================================
 * SECTION 5 — CHILDREN VT RANGE
 *
 * cl_cvtmin is used to snap a re-activating child's cl_vt so it
 * cannot undercut siblings that stayed active.
 * ================================================================ */

/**
 * refresh_children_vt_range — rescan all active children of a parent
 * and update cl_cvtmin / cl_cvtmax.  NULL-safe.
 */
static void
refresh_children_vt_range(hfsc_class_t *parent)
{
    if (parent == NULL)
        return;

    uint64_t min_vt = UINT64_MAX;
    uint64_t max_vt = 0;

    for (uint32_t i = 0; i < parent->num_children; i++) {
        hfsc_class_t *child = parent->children[i];
        if (!child->is_active)
            continue;
        if (child->cl_vt < min_vt) min_vt = child->cl_vt;
        if (child->cl_vt > max_vt) max_vt = child->cl_vt;
    }

    parent->cl_cvtmin = min_vt;
    parent->cl_cvtmax = max_vt;
}


/* ================================================================
 * SECTION 6 — RT ELIGIBLE / DEADLINE UPDATE
 * ================================================================ */

/**
 * rt_recompute_eligible_and_deadline — after a packet is dequeued and
 * cumul updated, compute cl_e and cl_d for the NEXT queued packet and
 * reposition the class in the RT heap.
 */
static void
rt_recompute_eligible_and_deadline(hfsc_scheduler_t *sched,
                                   hfsc_class_t     *cl)
{
    if (!cl->has_rsc)
        return;

    if (cl->qlen == 0) {
        deadline_heap_remove(sched, cl);
        return;
    }

    /* Peek at the next packet's length for an accurate deadline. */
    struct rte_mbuf *next_packet;
    uint32_t next_packet_bytes =
        (rte_ring_peek(cl->queue, (void **)&next_packet) == 0)
        ? rte_pktmbuf_pkt_len(next_packet)
        : 1500;

    cl->cl_e = curve_eval_inverse(&cl->rt_eligible_curve, cl->cumul);
    cl->cl_d = curve_eval_inverse(&cl->rt_deadline_curve,
                                   cl->cumul + next_packet_bytes);

    if (cl->deadline_heap_index >= 0)
        deadline_heap_reposition(sched, cl);
    else
        deadline_heap_insert(sched, cl);
}


/* ================================================================
 * SECTION 7 — VIRTUAL TIME UPDATE
 * ================================================================ */

/**
 * ls_update_leaf_virtual_time — recompute cl_vt for a leaf class only.
 * Interior node VT is updated in the dequeue ancestor-propagation loop,
 * which is the single authoritative place for interior node state.
 */
static void
ls_update_leaf_virtual_time(hfsc_class_t *leaf)
{
    leaf->cl_vt = curve_eval_inverse(&leaf->ls_virtual_time_curve,
                                      leaf->total)
                  + leaf->vt_offset;
}


/* ================================================================
 * SECTION 8 — CLASS ACTIVATION AND DEACTIVATION
 * ================================================================ */

/* Forward declaration (activation recurses up the tree). */
static void class_activate(hfsc_scheduler_t *sched, hfsc_class_t *cl);

/**
 * class_activate — transition a class from idle to active.
 *
 * 1. Re-anchor all curves at (now, bytes_served) — CRITICAL for
 *    correctness.  Curves anchored at TSC=0 give absurd results.
 *
 * 2. Compute vt_offset if this is a new deactivation period, so the
 *    class's cl_vt starts at max(raw_vt, parent->cl_cvtmin).
 *
 * 3. Recurse to activate the parent (no-op if already active).
 */
static void
class_activate(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (cl->is_active)
        return;

    cl->is_active = true;
    uint64_t now = rte_get_tsc_cycles();

    /* ---- RT curves (leaf only) ----
     * Use curve_segment_init so every field is written cleanly from the
     * user spec anchored at (now, cumul).  cl_e and cl_d are set in
     * hfsc_enqueue when the first packet arrives.
     */
    if (cl->has_rsc && cl->is_leaf) {
        curve_segment_init(&cl->rt_deadline_curve, &cl->rsc,
                           now, cl->cumul, sched->tsc_cycles_per_second);
        build_eligible_curve_from_rsc(&cl->rt_eligible_curve,
                                       &cl->rt_deadline_curve, &cl->rsc);
    }

    /* ---- USC ----
     * Re-anchor so cl_myf is relative to now.  If the class was idle
     * long enough for the USC budget to recover, cl_myf < now and there
     * is no restriction.
     */
    if (cl->has_usc) {
        curve_segment_reanchor(&cl->ul_fittime_curve, &cl->usc,
                                now, cl->total, sched->tsc_cycles_per_second);
        cl->cl_myf = curve_eval_inverse(&cl->ul_fittime_curve, cl->total);
    } else {
        cl->cl_myf = 0; /* 0 = no restriction */
    }

    /* ---- FSC / virtual time ----
     * Reanchor so cl_vt is computed relative to now, not TSC epoch 0.
     */
    curve_segment_reanchor(&cl->ls_virtual_time_curve, &cl->fsc,
                            now, cl->total, sched->tsc_cycles_per_second);

    uint64_t raw_virtual_time =
        curve_eval_inverse(&cl->ls_virtual_time_curve, cl->total);

    /* ---- VT period / offset logic ([1] Section 4.3) ----
     *
     * deactivation_generation is incremented on every deactivation.
     * saved_parent_generation records the value of deactivation_generation
     * at the last activation.  A mismatch means a new period has started.
     *
     * First activation: both == 0 → same period → no offset.
     * Re-activation after going idle: mismatch → new period → snap cl_vt.
     *
     * IMPORTANT: always reset vt_offset to 0 first, then conditionally
     * set it.  This prevents stale offsets from prior periods accumulating.
     */
    cl->vt_offset = 0;

    if (cl->parent != NULL
        && cl->deactivation_generation != cl->saved_parent_generation) {

        cl->saved_parent_generation = cl->deactivation_generation;

        uint64_t siblings_min_vt = cl->parent->cl_cvtmin;

        if (siblings_min_vt != UINT64_MAX
            && siblings_min_vt > raw_virtual_time)
            cl->vt_offset = siblings_min_vt - raw_virtual_time;
    }

    cl->cl_vt = raw_virtual_time + cl->vt_offset;

    /* Refresh parent's child VT range and activate parent if needed. */
    if (cl->parent != NULL) {
        refresh_children_vt_range(cl->parent);
        class_activate(sched, cl->parent);
    }
}

/**
 * class_deactivate — mark a class idle.
 *
 * Increments deactivation_generation so the next activation is
 * detected as a new period and vt_offset is recalculated.
 * Recursively deactivates the parent if no siblings remain active.
 */
static void
class_deactivate(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    if (!cl->is_active)
        return;

    deadline_heap_remove(sched, cl);
    cl->is_active = false;
    cl->deactivation_generation++;

    if (cl->parent == NULL)
        return;

    refresh_children_vt_range(cl->parent);

    /* Deactivate the parent if all its children are now idle. */
    bool any_child_still_active = false;
    for (uint32_t i = 0; i < cl->parent->num_children; i++) {
        if (cl->parent->children[i]->is_active) {
            any_child_still_active = true;
            break;
        }
    }

    if (!any_child_still_active)
        class_deactivate(sched, cl->parent);
}


/* ================================================================
 * SECTION 9 — PACKET SELECTION
 * ================================================================ */

/**
 * scheduler_pick_realtime_class — find the eligible RT class with
 * the earliest deadline.
 *
 * The heap is sorted by deadline; eligibility (cl_e <= now) is
 * independent, so we scan and pick the eligible minimum.
 * USC does NOT restrict RT selection per [1] Section 3.
 */
static hfsc_class_t *
scheduler_pick_realtime_class(hfsc_scheduler_t *sched)
{
    uint64_t      now               = rte_get_tsc_cycles();
    hfsc_class_t *best_class        = NULL;
    uint64_t      earliest_deadline = UINT64_MAX;

    for (uint32_t i = 0; i < sched->rt_heap_size; i++) {
        hfsc_class_t *candidate = sched->rt_deadline_heap[i];

        if (candidate->cl_e > now) continue; /* not yet eligible */
        if (candidate->qlen == 0)  continue; /* safety guard     */

        if (candidate->cl_d < earliest_deadline) {
            earliest_deadline = candidate->cl_d;
            best_class        = candidate;
        }
    }

    return best_class;
}

/**
 * scheduler_pick_linkshare_class — recursively pick the leaf with the
 * smallest cl_vt, obeying USC fit-time constraints.
 *
 * USC is checked on each node EXCEPT the root (root has no USC in
 * any valid hierarchy and checking it could erroneously block all traffic).
 */
static hfsc_class_t *
scheduler_pick_linkshare_class(hfsc_scheduler_t *sched, hfsc_class_t *cl)
{
    (void)sched;
    uint64_t now = rte_get_tsc_cycles();

    /* USC gate — skip for root class (parent == NULL). */
    if (cl->parent != NULL && cl->has_usc && cl->cl_myf > now)
        return NULL;

    /* Leaf: return if it has packets. */
    if (cl->is_leaf)
        return (cl->qlen > 0) ? cl : NULL;

    /* Interior: find the active child with the smallest cl_vt. */
    hfsc_class_t *best_child  = NULL;
    uint64_t      min_vt_seen = UINT64_MAX;

    for (uint32_t i = 0; i < cl->num_children; i++) {
        hfsc_class_t *child = cl->children[i];

        if (!child->is_active)
            continue;
        if (child->has_usc && child->cl_myf > now)
            continue;

        if (child->cl_vt < min_vt_seen) {
            min_vt_seen = child->cl_vt;
            best_child  = child;
        }
    }

    return (best_child != NULL)
           ? scheduler_pick_linkshare_class(sched, best_child)
           : NULL;
}


/* ================================================================
 * SECTION 10 — PUBLIC API
 * ================================================================ */

int
hfsc_init(hfsc_scheduler_t **sched_out)
{
    hfsc_scheduler_t *sched = rte_zmalloc("hfsc_scheduler",
                                           sizeof(*sched),
                                           RTE_CACHE_LINE_SIZE);
    if (sched == NULL)
        return -1;

    sched->rt_heap_capacity = HFSC_MAX_CLASSES;
    sched->rt_deadline_heap = rte_zmalloc(
                                  "hfsc_rt_heap",
                                  sizeof(hfsc_class_t *) * HFSC_MAX_CLASSES,
                                  RTE_CACHE_LINE_SIZE);
    if (sched->rt_deadline_heap == NULL) {
        rte_free(sched);
        return -1;
    }

    sched->tsc_cycles_per_second = rte_get_tsc_hz();
    HFSC_LOG(INFO, "HFSC v2.2 initialised (TSC = %lu Hz)\n",
             sched->tsc_cycles_per_second);
    *sched_out = sched;
    return 0;
}

void
hfsc_cleanup(hfsc_scheduler_t *sched)
{
    if (sched == NULL)
        return;

    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->all_classes[i];
        if (cl == NULL) continue;
        if (cl->queue != NULL) {
            struct rte_mbuf *leftover;
            while (rte_ring_dequeue(cl->queue, (void **)&leftover) == 0)
                rte_pktmbuf_free(leftover);
            rte_ring_free(cl->queue);
        }
        rte_free(cl);
    }

    rte_free(sched->rt_deadline_heap);
    rte_free(sched);
}

hfsc_class_t *
hfsc_create_root(hfsc_scheduler_t          *sched,
                 const hfsc_service_curve_t *rsc,
                 const hfsc_service_curve_t *fsc,
                 const hfsc_service_curve_t *usc)
{
    if (sched->root_class != NULL) {
        HFSC_LOG(ERR, "Root class already exists\n");
        return NULL;
    }
    return hfsc_create_class(sched, NULL, 0, false, rsc, fsc, usc);
}

hfsc_class_t *
hfsc_create_class(hfsc_scheduler_t          *sched,
                  hfsc_class_t              *parent,
                  uint32_t                   class_id,
                  bool                       is_leaf,
                  const hfsc_service_curve_t *rsc,
                  const hfsc_service_curve_t *fsc,
                  const hfsc_service_curve_t *usc)
{
    if (sched->num_classes >= HFSC_MAX_CLASSES) {
        HFSC_LOG(ERR, "Maximum class limit reached\n"); return NULL; }
    if (fsc == NULL || fsc->m2 == 0) {
        HFSC_LOG(ERR, "Class %u: FSC with m2 > 0 is required\n",
                 class_id); return NULL; }
    if (usc != NULL && usc->m2 < fsc->m2) {
        HFSC_LOG(ERR, "Class %u: USC m2 must be >= FSC m2\n",
                 class_id); return NULL; }
    if (parent != NULL && parent->num_children >= HFSC_MAX_CHILDREN) {
        HFSC_LOG(ERR, "Class %u: parent has too many children\n",
                 class_id); return NULL; }

    hfsc_class_t *cl = rte_zmalloc("hfsc_class", sizeof(*cl),
                                     RTE_CACHE_LINE_SIZE);
    if (cl == NULL) return NULL;

    cl->class_id            = class_id;
    cl->parent              = parent;
    cl->is_leaf             = is_leaf;
    cl->deadline_heap_index = -1;
    cl->cl_cvtmin           = UINT64_MAX;
    cl->cl_cvtmax           = 0;
    cl->cl_myf              = 0;

    cl->fsc = *fsc;
    if (rsc != NULL && (rsc->m1 != 0 || rsc->m2 != 0)) {
        cl->rsc = *rsc; cl->has_rsc = true;
    }
    if (usc != NULL && (usc->m1 != 0 || usc->m2 != 0)) {
        cl->usc = *usc; cl->has_usc = true;
    }

    /*
     * Initialise all curves anchored at (time=0, bytes=0).
     * On first activation, curve_segment_reanchor moves the anchor to
     * (now, 0) so all subsequent curve_eval_inverse calls return times
     * relative to the actual start, not TSC epoch zero.
     *
     * deactivation_generation == saved_parent_generation == 0 on first
     * activation → same period → vt_offset = 0 (correct: fresh class).
     */
    curve_segment_init(&cl->ls_virtual_time_curve, fsc,
                       0, 0, sched->tsc_cycles_per_second);
    if (cl->has_rsc)
        curve_segment_init(&cl->rt_deadline_curve, rsc,
                           0, 0, sched->tsc_cycles_per_second);
    if (cl->has_usc)
        curve_segment_init(&cl->ul_fittime_curve, usc,
                           0, 0, sched->tsc_cycles_per_second);

    if (is_leaf) {
        char queue_name[64];
        snprintf(queue_name, sizeof(queue_name), "hfsc_queue_%u", class_id);
        cl->queue = rte_ring_create(queue_name, HFSC_QUEUE_SIZE,
                                     rte_socket_id(),
                                     RING_F_SP_ENQ | RING_F_SC_DEQ);
        if (cl->queue == NULL) {
            HFSC_LOG(ERR, "Class %u: queue creation failed\n", class_id);
            rte_free(cl);
            return NULL;
        }
    }

    if (parent != NULL)
        parent->children[parent->num_children++] = cl;
    else
        sched->root_class = cl;

    sched->all_classes[sched->num_classes++] = cl;

    HFSC_LOG(INFO, "Class %u: %s  rsc=%s usc=%s  fsc=%lu/%luus/%lu bps\n",
             class_id,
             is_leaf ? "leaf" : "interior",
             cl->has_rsc ? "yes" : "no",
             cl->has_usc ? "yes" : "no",
             fsc->m1, fsc->d, fsc->m2);
    return cl;
}

int
hfsc_enqueue(hfsc_scheduler_t *sched,
             hfsc_class_t     *leaf_class,
             struct rte_mbuf  *packet)
{
    if (!leaf_class->is_leaf) {
        HFSC_LOG(ERR, "Class %u is not a leaf\n", leaf_class->class_id);
        leaf_class->stat_packets_dropped++;
        sched->total_packets_dropped++;
        return -1;
    }

    if (rte_ring_full(leaf_class->queue)) {
        leaf_class->stat_packets_dropped++;
        sched->total_packets_dropped++;
        return -1;
    }

    uint32_t packet_bytes  = rte_pktmbuf_pkt_len(packet);
    bool     queue_was_empty = (leaf_class->qlen == 0);

    if (rte_ring_enqueue(leaf_class->queue, packet) < 0) {
        leaf_class->stat_packets_dropped++;
        sched->total_packets_dropped++;
        return -1;
    }

    leaf_class->qlen++;
    leaf_class->qbytes += packet_bytes;
    sched->total_packets_enqueued++;

    if (queue_was_empty) {
        /*
         * First packet in an empty queue — activate the class hierarchy.
         * class_activate re-anchors all curves at (now, cumul/total).
         */
        class_activate(sched, leaf_class);

        if (leaf_class->has_rsc) {
            /*
             * Set the initial eligible time and deadline for this packet.
             * cl_e = when the class becomes eligible for RT scheduling.
             * cl_d = deadline by which this packet must be sent.
             */
            leaf_class->cl_e =
                curve_eval_inverse(&leaf_class->rt_eligible_curve,
                                    leaf_class->cumul);
            leaf_class->cl_d =
                curve_eval_inverse(&leaf_class->rt_deadline_curve,
                                    leaf_class->cumul + packet_bytes);
            deadline_heap_insert(sched, leaf_class);
        }
    }

    return 0;
}

struct rte_mbuf *
hfsc_dequeue(hfsc_scheduler_t *sched)
{
    if (sched->root_class == NULL || !sched->root_class->is_active)
        return NULL;

    /*
     * Selection order:
     *   1. RT  — eligible class with the earliest deadline.
     *   2. LS  — class with the smallest virtual time (USC-gated).
     */
    hfsc_class_t *selected =
        scheduler_pick_realtime_class(sched);
    if (selected == NULL)
        selected = scheduler_pick_linkshare_class(sched, sched->root_class);
    if (selected == NULL)
        return NULL;

    struct rte_mbuf *packet;
    if (rte_ring_dequeue(selected->queue, (void **)&packet) < 0)
        return NULL;

    uint32_t packet_bytes = rte_pktmbuf_pkt_len(packet);

    selected->qlen--;
    if (selected->qbytes >= packet_bytes)
        selected->qbytes -= packet_bytes;
    else
        selected->qbytes = 0;

    /*
     * Both counters advance together for leaf classes.
     *   cumul → drives rt_deadline_curve / rt_eligible_curve inverses.
     *   total → drives ls_virtual_time_curve / ul_fittime_curve inverses.
     */
    selected->cumul += packet_bytes;
    selected->total += packet_bytes;
    selected->stat_packets_sent++;
    selected->stat_bytes_sent += packet_bytes;
    sched->total_packets_dequeued++;

    uint64_t now = rte_get_tsc_cycles();

    /* ---- Update RT curves and heap ---- */
    if (selected->has_rsc) {
        curve_segment_reanchor(&selected->rt_deadline_curve, &selected->rsc,
                                now, selected->cumul,
                                sched->tsc_cycles_per_second);
        build_eligible_curve_from_rsc(&selected->rt_eligible_curve,
                                       &selected->rt_deadline_curve,
                                       &selected->rsc);
        rt_recompute_eligible_and_deadline(sched, selected);
    }

    /* ---- Update FSC / virtual time for the leaf ---- */
    curve_segment_reanchor(&selected->ls_virtual_time_curve, &selected->fsc,
                            now, selected->total, sched->tsc_cycles_per_second);
    ls_update_leaf_virtual_time(selected);

    /* ---- Update USC fit-time for the leaf ---- */
    if (selected->has_usc) {
        curve_segment_reanchor(&selected->ul_fittime_curve, &selected->usc,
                                now, selected->total,
                                sched->tsc_cycles_per_second);
        selected->cl_myf =
            curve_eval_inverse(&selected->ul_fittime_curve, selected->total);
    }

    /*
     * Propagate up the ancestor chain.
     * Each interior node's total/cumul, FSC/USC curves, cl_vt, and
     * cl_cvtmin/max are updated here.  This is the single authoritative
     * place for interior node state — ls_update_leaf_virtual_time only
     * touches the leaf itself.
     */
    for (hfsc_class_t *ancestor = selected->parent;
         ancestor != NULL;
         ancestor = ancestor->parent) {

        ancestor->total += packet_bytes;
        ancestor->cumul += packet_bytes;

        /* Reanchor FSC and recompute cl_vt. */
        curve_segment_reanchor(&ancestor->ls_virtual_time_curve,
                                &ancestor->fsc,
                                now, ancestor->total,
                                sched->tsc_cycles_per_second);
        ancestor->cl_vt =
            curve_eval_inverse(&ancestor->ls_virtual_time_curve,
                                ancestor->total)
            + ancestor->vt_offset;

        /* Refresh the children VT range so this ancestor's siblings
         * see an up-to-date cl_cvtmin when selecting between subtrees. */
        refresh_children_vt_range(ancestor);

        /* USC fit-time. */
        if (ancestor->has_usc) {
            curve_segment_reanchor(&ancestor->ul_fittime_curve,
                                    &ancestor->usc,
                                    now, ancestor->total,
                                    sched->tsc_cycles_per_second);
            ancestor->cl_myf =
                curve_eval_inverse(&ancestor->ul_fittime_curve,
                                    ancestor->total);
        }
    }

    /* Deactivate the leaf if its queue is now empty. */
    if (selected->qlen == 0)
        class_deactivate(sched, selected);

    return packet;
}

bool
hfsc_has_packets(hfsc_scheduler_t *sched)
{
    return (sched->root_class != NULL && sched->root_class->is_active);
}

void
hfsc_get_class_stats(hfsc_class_t *cl,
                     uint64_t     *packets_sent,
                     uint64_t     *bytes_sent,
                     uint64_t     *packets_dropped)
{
    if (packets_sent)    *packets_sent    = cl->stat_packets_sent;
    if (bytes_sent)      *bytes_sent      = cl->stat_bytes_sent;
    if (packets_dropped) *packets_dropped = cl->stat_packets_dropped;
}

void
hfsc_dump_state(hfsc_scheduler_t *sched)
{
    printf("=== HFSC v2.2 State ===\n");
    printf("  Classes: %u  Enqueued: %lu  Dequeued: %lu  Dropped: %lu\n",
           sched->num_classes,
           sched->total_packets_enqueued,
           sched->total_packets_dequeued,
           sched->total_packets_dropped);

    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->all_classes[i];
        printf("  class %-3u [%s] active=%d qlen=%-4u "
               "total=%-12lu cumul=%-12lu cl_vt=%-20lu cl_myf=%-20lu\n",
               cl->class_id,
               cl->is_leaf ? "leaf" : "int ",
               cl->is_active, cl->qlen,
               cl->total, cl->cumul, cl->cl_vt, cl->cl_myf);
    }
    printf("=======================\n");
}

void
hfsc_dump_vt_state(hfsc_scheduler_t *sched)
{
    printf("=== HFSC v2.2 VT State  (RT heap: %u entries) ===\n",
           sched->rt_heap_size);

    for (uint32_t i = 0; i < sched->num_classes; i++) {
        hfsc_class_t *cl = sched->all_classes[i];
        if (!cl->is_active) continue;

        printf("  class %-3u  cl_vt=%-20lu  vt_offset=%-12lu"
               "  cl_cvtmin=%-20lu  gen=%u/%u",
               cl->class_id, cl->cl_vt, cl->vt_offset,
               (cl->cl_cvtmin == UINT64_MAX) ? 0 : cl->cl_cvtmin,
               cl->deactivation_generation,
               cl->saved_parent_generation);

        if (cl->has_rsc)
            printf("  RT[cl_e=%-20lu  cl_d=%-20lu]",
                   cl->cl_e, cl->cl_d);
        printf("\n");
    }
    printf("==================================================\n");
}
